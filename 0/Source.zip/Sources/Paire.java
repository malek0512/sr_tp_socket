package jus.aor.printing;
/**
 * J<i>ava</i> U<i>tilities</i> for S<i>tudents</i>
 */


/**
 * @author morat 
 */
public class Paire<A,B> {
	public A cle;
	public B value;
	/**
	 * @param cle
	 * @param value
	 */
	public Paire(A cle, B value) {this.cle=cle; this.value=value;}
}
